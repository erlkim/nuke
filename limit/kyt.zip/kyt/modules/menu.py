from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline(" SSH OVPN MANAGER ","ssh"),
Button.inline(" VMESS MANAGER ","vmess")],
[Button.inline(" VLESS MANAGER ","vless"),
[Button.inline(" TROJAN MANAGER ","trojan")],
[Button.inline(" ‹ Back Menu › ","start")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":

		msg = f"""
**✧◇───────────────────◇✧**
**     __BOT PANEL PREMIUM__ **
**✧◇───────────────────◇✧**
** Hallo {sender.first_name}**
** User ID :** `{sender.id}`
** Email :** `{sender.username}@satanfusion.net`
**✧◇───────────────────◇✧**
** Masih Dalam Tahap Pengembangan**
** Owner :** @abecasdee (**AdminSF**)
**✧◇───────────────────◇✧**
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)


